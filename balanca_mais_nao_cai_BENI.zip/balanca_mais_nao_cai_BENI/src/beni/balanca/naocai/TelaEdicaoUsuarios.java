package beni.balanca.naocai;

/** Tela editável na aba Design do NetBeans. */
public class TelaEdicaoUsuarios extends javax.swing.JPanel {
    public TelaEdicaoUsuarios() {
        initComponents();
        if (App.registro != null) { campo0.setText(App.registro[1]); campo1.setText(App.registro[2]);  }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        titulo = new javax.swing.JLabel();
        rotulo0 = new javax.swing.JLabel();
        campo0 = new javax.swing.JTextField();
        rotulo1 = new javax.swing.JLabel();
        campo1 = new javax.swing.JTextField();
        rotulo2 = new javax.swing.JLabel();
        campo2 = new javax.swing.JPasswordField();
        salvar = new javax.swing.JButton();
        limpar = new javax.swing.JButton();
        voltar = new javax.swing.JButton();
        navInclusao = new javax.swing.JButton();
        navConsulta = new javax.swing.JButton();
        navAlteracao = new javax.swing.JButton();
        navExclusao = new javax.swing.JButton();
        marca = new javax.swing.JLabel();
        legendaMarca = new javax.swing.JLabel();
        lateralFases = new javax.swing.JButton();
        lateralEngenheiros = new javax.swing.JButton();
        lateralFuncoes = new javax.swing.JButton();
        lateralUsuarios = new javax.swing.JButton();
        inicio = new javax.swing.JButton();
        linhaTopo = new javax.swing.JLabel();
        rodape = new javax.swing.JLabel();
        fundoFormulario = new javax.swing.JLabel();
        fundoLateral = new javax.swing.JLabel();

        setPreferredSize(new java.awt.Dimension(980, 660));
        setLayout(null);

        titulo.setText("Alterar Usuários");
        titulo.setFont(new java.awt.Font("Dialog", 0, 23)); // NOI18N
        titulo.setForeground(new java.awt.Color(45, 45, 45));
        add(titulo);
        titulo.setBounds(260, 44, 680, 38);

        rotulo0.setText("Nome");
        rotulo0.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        add(rotulo0);
        rotulo0.setBounds(290, 195, 580, 25);

        campo0.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        add(campo0);
        campo0.setBounds(290, 225, 480, 36);

        rotulo1.setText("E-mail");
        rotulo1.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        add(rotulo1);
        rotulo1.setBounds(290, 285, 580, 25);

        campo1.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        add(campo1);
        campo1.setBounds(290, 315, 480, 36);

        rotulo2.setText("Senha (vazia: manter)");
        rotulo2.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        add(rotulo2);
        rotulo2.setBounds(290, 375, 580, 25);

        campo2.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        add(campo2);
        campo2.setBounds(290, 405, 480, 36);

        salvar.setText("Salvar");
        salvar.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        salvar.setBackground(new java.awt.Color(205, 205, 205));
        salvar.setForeground(new java.awt.Color(45, 45, 45));
        salvar.setOpaque(true);
        salvar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                salvarActionPerformed(evt);
            }
        });
        add(salvar);
        salvar.setBounds(290, 510, 180, 38);

        limpar.setText("Limpar");
        limpar.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        limpar.setBackground(new java.awt.Color(232, 232, 232));
        limpar.setForeground(new java.awt.Color(45, 45, 45));
        limpar.setOpaque(true);
        limpar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                limparActionPerformed(evt);
            }
        });
        add(limpar);
        limpar.setBounds(485, 510, 130, 38);

        voltar.setText("Voltar");
        voltar.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        voltar.setBackground(new java.awt.Color(232, 232, 232));
        voltar.setForeground(new java.awt.Color(45, 45, 45));
        voltar.setOpaque(true);
        voltar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                voltarActionPerformed(evt);
            }
        });
        add(voltar);
        voltar.setBounds(630, 510, 140, 38);

        navInclusao.setText("Incluir");
        navInclusao.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        navInclusao.setBackground(new java.awt.Color(232, 232, 232));
        navInclusao.setForeground(new java.awt.Color(45, 45, 45));
        navInclusao.setOpaque(true);
        navInclusao.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                navInclusaoActionPerformed(evt);
            }
        });
        add(navInclusao);
        navInclusao.setBounds(260, 120, 155, 35);

        navConsulta.setText("Consultar");
        navConsulta.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        navConsulta.setBackground(new java.awt.Color(232, 232, 232));
        navConsulta.setForeground(new java.awt.Color(45, 45, 45));
        navConsulta.setOpaque(true);
        navConsulta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                navConsultaActionPerformed(evt);
            }
        });
        add(navConsulta);
        navConsulta.setBounds(427, 120, 155, 35);

        navAlteracao.setText("Alterar");
        navAlteracao.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        navAlteracao.setBackground(new java.awt.Color(232, 232, 232));
        navAlteracao.setForeground(new java.awt.Color(45, 45, 45));
        navAlteracao.setOpaque(true);
        navAlteracao.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                navAlteracaoActionPerformed(evt);
            }
        });
        add(navAlteracao);
        navAlteracao.setBounds(594, 120, 155, 35);

        navExclusao.setText("Excluir");
        navExclusao.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        navExclusao.setBackground(new java.awt.Color(232, 232, 232));
        navExclusao.setForeground(new java.awt.Color(45, 45, 45));
        navExclusao.setOpaque(true);
        navExclusao.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                navExclusaoActionPerformed(evt);
            }
        });
        add(navExclusao);
        navExclusao.setBounds(761, 120, 155, 35);

        marca.setFont(new java.awt.Font("Dialog", 0, 32)); // NOI18N
        marca.setForeground(new java.awt.Color(45, 45, 45));
        add(marca);
        marca.setBounds(24, 30, 170, 50);

        legendaMarca.setText("Controle de obras");
        legendaMarca.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        legendaMarca.setForeground(new java.awt.Color(45, 45, 45));
        add(legendaMarca);
        legendaMarca.setBounds(24, 85, 180, 28);

        lateralFases.setText("Fases");
        lateralFases.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        lateralFases.setBackground(new java.awt.Color(232, 232, 232));
        lateralFases.setForeground(new java.awt.Color(45, 45, 45));
        lateralFases.setOpaque(true);
        lateralFases.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                lateralFasesActionPerformed(evt);
            }
        });
        add(lateralFases);
        lateralFases.setBounds(18, 160, 174, 35);

        lateralEngenheiros.setText("Engenheiros");
        lateralEngenheiros.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        lateralEngenheiros.setBackground(new java.awt.Color(232, 232, 232));
        lateralEngenheiros.setForeground(new java.awt.Color(45, 45, 45));
        lateralEngenheiros.setOpaque(true);
        lateralEngenheiros.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                lateralEngenheirosActionPerformed(evt);
            }
        });
        add(lateralEngenheiros);
        lateralEngenheiros.setBounds(18, 216, 174, 35);

        lateralFuncoes.setText("Funções");
        lateralFuncoes.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        lateralFuncoes.setBackground(new java.awt.Color(232, 232, 232));
        lateralFuncoes.setForeground(new java.awt.Color(45, 45, 45));
        lateralFuncoes.setOpaque(true);
        lateralFuncoes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                lateralFuncoesActionPerformed(evt);
            }
        });
        add(lateralFuncoes);
        lateralFuncoes.setBounds(18, 272, 174, 35);

        lateralUsuarios.setText("Usuários");
        lateralUsuarios.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        lateralUsuarios.setBackground(new java.awt.Color(205, 205, 205));
        lateralUsuarios.setForeground(new java.awt.Color(45, 45, 45));
        lateralUsuarios.setOpaque(true);
        lateralUsuarios.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                lateralUsuariosActionPerformed(evt);
            }
        });
        add(lateralUsuarios);
        lateralUsuarios.setBounds(18, 328, 174, 35);

        inicio.setText("Menu principal");
        inicio.setBackground(new java.awt.Color(232, 232, 232));
        inicio.setOpaque(true);
        inicio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inicioActionPerformed(evt);
            }
        });
        add(inicio);
        inicio.setBounds(18, 452, 174, 35);

        linhaTopo.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        linhaTopo.setBackground(new java.awt.Color(205, 205, 205));
        linhaTopo.setOpaque(true);
        add(linhaTopo);
        linhaTopo.setBounds(260, 96, 660, 4);

        rodape.setText("Balança Mais Não Cai");
        rodape.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        rodape.setForeground(new java.awt.Color(45, 45, 45));
        add(rodape);
        rodape.setBounds(260, 610, 650, 25);

        fundoFormulario.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        fundoFormulario.setBackground(new java.awt.Color(255, 255, 255));
        fundoFormulario.setOpaque(true);
        add(fundoFormulario);
        fundoFormulario.setBounds(260, 180, 660, 390);

        fundoLateral.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        fundoLateral.setBackground(new java.awt.Color(218, 218, 218));
        fundoLateral.setOpaque(true);
        add(fundoLateral);
        fundoLateral.setBounds(0, 0, 210, 660);
    }// </editor-fold>//GEN-END:initComponents

    private void salvarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_salvarActionPerformed
        try { String[] valores = new String[] {campo0.getText(), campo1.getText(), new String(campo2.getPassword())}; App.dados.alterar(3, Integer.parseInt(App.registro[0]), valores); App.aviso("Registro salvo com sucesso."); App.abrir("TelaAlteracaoUsuarios"); } catch (Exception ex) { App.aviso(ex.getMessage()); }
    }//GEN-LAST:event_salvarActionPerformed

    private void limparActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_limparActionPerformed
        campo0.setText(""); campo1.setText(""); campo2.setText("");
    }//GEN-LAST:event_limparActionPerformed

    private void voltarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_voltarActionPerformed
        App.abrir("TelaAlteracaoUsuarios");
    }//GEN-LAST:event_voltarActionPerformed

    private void navInclusaoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_navInclusaoActionPerformed
        App.abrir("TelaInclusaoUsuarios");
    }//GEN-LAST:event_navInclusaoActionPerformed

    private void navConsultaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_navConsultaActionPerformed
        App.abrir("TelaConsultaUsuarios");
    }//GEN-LAST:event_navConsultaActionPerformed

    private void navAlteracaoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_navAlteracaoActionPerformed
        App.abrir("TelaAlteracaoUsuarios");
    }//GEN-LAST:event_navAlteracaoActionPerformed

    private void navExclusaoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_navExclusaoActionPerformed
        App.abrir("TelaExclusaoUsuarios");
    }//GEN-LAST:event_navExclusaoActionPerformed

    private void lateralFasesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_lateralFasesActionPerformed
        App.abrir("TelaManutencaoFases");
    }//GEN-LAST:event_lateralFasesActionPerformed

    private void lateralEngenheirosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_lateralEngenheirosActionPerformed
        App.abrir("TelaManutencaoEngenheiros");
    }//GEN-LAST:event_lateralEngenheirosActionPerformed

    private void lateralFuncoesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_lateralFuncoesActionPerformed
        App.abrir("TelaManutencaoFuncoes");
    }//GEN-LAST:event_lateralFuncoesActionPerformed

    private void lateralUsuariosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_lateralUsuariosActionPerformed
        App.abrir("TelaManutencaoUsuarios");
    }//GEN-LAST:event_lateralUsuariosActionPerformed

    private void inicioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inicioActionPerformed
        App.abrir("TelaMenu");
    }//GEN-LAST:event_inicioActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField campo0;
    private javax.swing.JTextField campo1;
    private javax.swing.JPasswordField campo2;
    private javax.swing.JLabel fundoFormulario;
    private javax.swing.JLabel fundoLateral;
    private javax.swing.JButton inicio;
    private javax.swing.JButton lateralEngenheiros;
    private javax.swing.JButton lateralFases;
    private javax.swing.JButton lateralFuncoes;
    private javax.swing.JButton lateralUsuarios;
    private javax.swing.JLabel legendaMarca;
    private javax.swing.JButton limpar;
    private javax.swing.JLabel linhaTopo;
    private javax.swing.JLabel marca;
    private javax.swing.JButton navAlteracao;
    private javax.swing.JButton navConsulta;
    private javax.swing.JButton navExclusao;
    private javax.swing.JButton navInclusao;
    private javax.swing.JLabel rodape;
    private javax.swing.JLabel rotulo0;
    private javax.swing.JLabel rotulo1;
    private javax.swing.JLabel rotulo2;
    private javax.swing.JButton salvar;
    private javax.swing.JLabel titulo;
    private javax.swing.JButton voltar;
    // End of variables declaration//GEN-END:variables
}
