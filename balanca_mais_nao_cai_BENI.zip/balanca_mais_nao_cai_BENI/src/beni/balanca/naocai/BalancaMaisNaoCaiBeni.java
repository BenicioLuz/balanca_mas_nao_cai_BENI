package beni.balanca.naocai;
public class BalancaMaisNaoCaiBeni {
 public static void main(String[] args) {
  javax.swing.SwingUtilities.invokeLater(() -> { try {
   javax.swing.plaf.metal.MetalLookAndFeel.setCurrentTheme(new javax.swing.plaf.metal.DefaultMetalTheme() {
    protected javax.swing.plaf.ColorUIResource getPrimary1() { return new javax.swing.plaf.ColorUIResource(90,90,90); }
    protected javax.swing.plaf.ColorUIResource getPrimary2() { return new javax.swing.plaf.ColorUIResource(160,160,160); }
    protected javax.swing.plaf.ColorUIResource getPrimary3() { return new javax.swing.plaf.ColorUIResource(220,220,220); }
   });
   javax.swing.UIManager.setLookAndFeel(javax.swing.UIManager.getCrossPlatformLookAndFeelClassName());
   App.dados=new Dados(java.nio.file.Paths.get(System.getProperty("fabian.dados","dados/cadastros.xml")));
   App.janela=new javax.swing.JFrame("Balança Mais Não Cai");
   App.janela.setDefaultCloseOperation(javax.swing.JFrame.EXIT_ON_CLOSE);
   App.abrir("TelaLogin"); App.janela.pack(); App.janela.setResizable(false); App.janela.setLocationRelativeTo(null); App.janela.setVisible(true);
  } catch(Exception ex) { ex.printStackTrace(); javax.swing.JOptionPane.showMessageDialog(null,ex.getMessage()); } });
 }
}
