package beni.balanca.naocai;

/** Tela editável na aba Design do NetBeans. */
public class TelaManutencaoUsuarios extends javax.swing.JPanel {
    public TelaManutencaoUsuarios() {
        initComponents();
        
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        titulo = new javax.swing.JLabel();
        acao0 = new javax.swing.JButton();
        acao1 = new javax.swing.JButton();
        acao2 = new javax.swing.JButton();
        acao3 = new javax.swing.JButton();
        voltar = new javax.swing.JButton();
        marca = new javax.swing.JLabel();
        legendaMarca = new javax.swing.JLabel();
        lateralFases = new javax.swing.JButton();
        lateralEngenheiros = new javax.swing.JButton();
        lateralFuncoes = new javax.swing.JButton();
        lateralUsuarios = new javax.swing.JButton();
        inicio = new javax.swing.JButton();
        linhaTopo = new javax.swing.JLabel();
        rodape = new javax.swing.JLabel();
        intro = new javax.swing.JLabel();
        fundoLateral = new javax.swing.JLabel();

        setPreferredSize(new java.awt.Dimension(980, 660));
        setLayout(null);

        titulo.setText("Manutenção de Usuários");
        titulo.setFont(new java.awt.Font("Dialog", 0, 23)); // NOI18N
        titulo.setForeground(new java.awt.Color(45, 45, 45));
        add(titulo);
        titulo.setBounds(260, 44, 680, 38);

        acao0.setText("Cadastrar novo");
        acao0.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N
        acao0.setBackground(new java.awt.Color(205, 205, 205));
        acao0.setForeground(new java.awt.Color(45, 45, 45));
        acao0.setOpaque(true);
        acao0.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                acao0ActionPerformed(evt);
            }
        });
        add(acao0);
        acao0.setBounds(280, 195, 290, 85);

        acao1.setText("Consultar registros");
        acao1.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N
        acao1.setBackground(new java.awt.Color(232, 232, 232));
        acao1.setForeground(new java.awt.Color(45, 45, 45));
        acao1.setOpaque(true);
        acao1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                acao1ActionPerformed(evt);
            }
        });
        add(acao1);
        acao1.setBounds(600, 195, 290, 85);

        acao2.setText("Editar cadastro");
        acao2.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N
        acao2.setBackground(new java.awt.Color(232, 232, 232));
        acao2.setForeground(new java.awt.Color(45, 45, 45));
        acao2.setOpaque(true);
        acao2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                acao2ActionPerformed(evt);
            }
        });
        add(acao2);
        acao2.setBounds(280, 320, 290, 85);

        acao3.setText("Excluir cadastro");
        acao3.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N
        acao3.setBackground(new java.awt.Color(232, 232, 232));
        acao3.setForeground(new java.awt.Color(45, 45, 45));
        acao3.setOpaque(true);
        acao3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                acao3ActionPerformed(evt);
            }
        });
        add(acao3);
        acao3.setBounds(600, 320, 290, 85);

        voltar.setText("Voltar ao menu");
        voltar.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        voltar.setBackground(new java.awt.Color(232, 232, 232));
        voltar.setForeground(new java.awt.Color(45, 45, 45));
        voltar.setOpaque(true);
        voltar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                voltarActionPerformed(evt);
            }
        });
        add(voltar);
        voltar.setBounds(730, 520, 185, 38);

        marca.setFont(new java.awt.Font("Dialog", 0, 32)); // NOI18N
        marca.setForeground(new java.awt.Color(45, 45, 45));
        add(marca);
        marca.setBounds(24, 30, 170, 50);

        legendaMarca.setText("Controle de obras");
        legendaMarca.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        legendaMarca.setForeground(new java.awt.Color(45, 45, 45));
        add(legendaMarca);
        legendaMarca.setBounds(24, 85, 180, 28);

        lateralFases.setText("Fases");
        lateralFases.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        lateralFases.setBackground(new java.awt.Color(232, 232, 232));
        lateralFases.setForeground(new java.awt.Color(45, 45, 45));
        lateralFases.setOpaque(true);
        lateralFases.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                lateralFasesActionPerformed(evt);
            }
        });
        add(lateralFases);
        lateralFases.setBounds(18, 160, 174, 35);

        lateralEngenheiros.setText("Engenheiros");
        lateralEngenheiros.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        lateralEngenheiros.setBackground(new java.awt.Color(232, 232, 232));
        lateralEngenheiros.setForeground(new java.awt.Color(45, 45, 45));
        lateralEngenheiros.setOpaque(true);
        lateralEngenheiros.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                lateralEngenheirosActionPerformed(evt);
            }
        });
        add(lateralEngenheiros);
        lateralEngenheiros.setBounds(18, 216, 174, 35);

        lateralFuncoes.setText("Funções");
        lateralFuncoes.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        lateralFuncoes.setBackground(new java.awt.Color(232, 232, 232));
        lateralFuncoes.setForeground(new java.awt.Color(45, 45, 45));
        lateralFuncoes.setOpaque(true);
        lateralFuncoes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                lateralFuncoesActionPerformed(evt);
            }
        });
        add(lateralFuncoes);
        lateralFuncoes.setBounds(18, 272, 174, 35);

        lateralUsuarios.setText("Usuários");
        lateralUsuarios.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        lateralUsuarios.setBackground(new java.awt.Color(205, 205, 205));
        lateralUsuarios.setForeground(new java.awt.Color(45, 45, 45));
        lateralUsuarios.setOpaque(true);
        lateralUsuarios.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                lateralUsuariosActionPerformed(evt);
            }
        });
        add(lateralUsuarios);
        lateralUsuarios.setBounds(18, 328, 174, 35);

        inicio.setText("Menu principal");
        inicio.setBackground(new java.awt.Color(232, 232, 232));
        inicio.setOpaque(true);
        inicio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inicioActionPerformed(evt);
            }
        });
        add(inicio);
        inicio.setBounds(18, 452, 174, 35);

        linhaTopo.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        linhaTopo.setBackground(new java.awt.Color(205, 205, 205));
        linhaTopo.setOpaque(true);
        add(linhaTopo);
        linhaTopo.setBounds(260, 96, 660, 4);

        rodape.setText("Balança Mais Não Cai");
        rodape.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        rodape.setForeground(new java.awt.Color(45, 45, 45));
        add(rodape);
        rodape.setBounds(260, 610, 650, 25);

        intro.setText("Selecione a operação desejada para este cadastro.");
        intro.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        intro.setForeground(new java.awt.Color(45, 45, 45));
        add(intro);
        intro.setBounds(260, 115, 660, 30);

        fundoLateral.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        fundoLateral.setBackground(new java.awt.Color(218, 218, 218));
        fundoLateral.setOpaque(true);
        add(fundoLateral);
        fundoLateral.setBounds(0, 0, 210, 660);
    }// </editor-fold>//GEN-END:initComponents

    private void acao0ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_acao0ActionPerformed
        App.abrir("TelaInclusaoUsuarios");
    }//GEN-LAST:event_acao0ActionPerformed

    private void acao1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_acao1ActionPerformed
        App.abrir("TelaConsultaUsuarios");
    }//GEN-LAST:event_acao1ActionPerformed

    private void acao2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_acao2ActionPerformed
        App.abrir("TelaAlteracaoUsuarios");
    }//GEN-LAST:event_acao2ActionPerformed

    private void acao3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_acao3ActionPerformed
        App.abrir("TelaExclusaoUsuarios");
    }//GEN-LAST:event_acao3ActionPerformed

    private void voltarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_voltarActionPerformed
        App.abrir("TelaMenu");
    }//GEN-LAST:event_voltarActionPerformed

    private void lateralFasesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_lateralFasesActionPerformed
        App.abrir("TelaManutencaoFases");
    }//GEN-LAST:event_lateralFasesActionPerformed

    private void lateralEngenheirosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_lateralEngenheirosActionPerformed
        App.abrir("TelaManutencaoEngenheiros");
    }//GEN-LAST:event_lateralEngenheirosActionPerformed

    private void lateralFuncoesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_lateralFuncoesActionPerformed
        App.abrir("TelaManutencaoFuncoes");
    }//GEN-LAST:event_lateralFuncoesActionPerformed

    private void lateralUsuariosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_lateralUsuariosActionPerformed
        App.abrir("TelaManutencaoUsuarios");
    }//GEN-LAST:event_lateralUsuariosActionPerformed

    private void inicioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inicioActionPerformed
        App.abrir("TelaMenu");
    }//GEN-LAST:event_inicioActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton acao0;
    private javax.swing.JButton acao1;
    private javax.swing.JButton acao2;
    private javax.swing.JButton acao3;
    private javax.swing.JLabel fundoLateral;
    private javax.swing.JButton inicio;
    private javax.swing.JLabel intro;
    private javax.swing.JButton lateralEngenheiros;
    private javax.swing.JButton lateralFases;
    private javax.swing.JButton lateralFuncoes;
    private javax.swing.JButton lateralUsuarios;
    private javax.swing.JLabel legendaMarca;
    private javax.swing.JLabel linhaTopo;
    private javax.swing.JLabel marca;
    private javax.swing.JLabel rodape;
    private javax.swing.JLabel titulo;
    private javax.swing.JButton voltar;
    // End of variables declaration//GEN-END:variables
}
