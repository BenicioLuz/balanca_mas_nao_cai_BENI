package beni.balanca.naocai;

/** Tela editável na aba Design do NetBeans. */
public class TelaAlteracaoUsuarios extends javax.swing.JPanel {
    public TelaAlteracaoUsuarios() {
        initComponents();
        carregar();
    }
    private java.util.List<String[]> registros;
    private void carregar() {
        if (App.dados == null) return;
        registros = App.dados.listar(3);
        javax.swing.table.DefaultTableModel modelo = new javax.swing.table.DefaultTableModel(new String[] {"Código", "Nome", "E-mail"}, 0) { public boolean isCellEditable(int r, int c) { return false; } };
        for (String[] r : registros) modelo.addRow(java.util.Arrays.copyOf(r, 3));
        tabela.setModel(modelo); tabela.setRowHeight(28); tabela.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION); tabela.getTableHeader().setReorderingAllowed(false);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {
        titulo = new javax.swing.JLabel();
        rolagem = new javax.swing.JScrollPane();
        instrucao = new javax.swing.JLabel();
        executar = new javax.swing.JButton();
        voltar = new javax.swing.JButton();
        navInclusao = new javax.swing.JButton();
        navConsulta = new javax.swing.JButton();
        navAlteracao = new javax.swing.JButton();
        navExclusao = new javax.swing.JButton();
        marca = new javax.swing.JLabel();
        legendaMarca = new javax.swing.JLabel();
        lateralFases = new javax.swing.JButton();
        lateralEngenheiros = new javax.swing.JButton();
        lateralFuncoes = new javax.swing.JButton();
        lateralUsuarios = new javax.swing.JButton();
        inicio = new javax.swing.JButton();
        linhaTopo = new javax.swing.JLabel();
        rodape = new javax.swing.JLabel();
        fundoLateral = new javax.swing.JLabel();
        setPreferredSize(new java.awt.Dimension(980, 660));
        setLayout(null);
        setBackground(new java.awt.Color(242,242,242));
        titulo.setText("Alteração de Usuários");
        titulo.setFont(new java.awt.Font("Dialog", 0, 23));
        titulo.setForeground(new java.awt.Color(45,45,45));
        add(titulo);
        titulo.setBounds(260, 44, 680, 38);
        rolagem.setFont(new java.awt.Font("Dialog", 0, 14));
        tabela = new javax.swing.JTable();
        tabela.setModel(new javax.swing.table.DefaultTableModel(new Object[][] {}, new String[] {"Código", "Descrição"}));
        rolagem.setViewportView(tabela);
        add(rolagem);
        rolagem.setBounds(260, 185, 660, 340);
        instrucao.setText("Selecione uma linha e clique no botão abaixo.");
        instrucao.setFont(new java.awt.Font("Dialog", 0, 14));
        add(instrucao);
        instrucao.setBounds(260, 535, 660, 25);
        executar.setText("Alterar selecionado");
        executar.setFont(new java.awt.Font("Dialog", 0, 14));
        executar.setBackground(new java.awt.Color(205,205,205));
        executar.setOpaque(true);
        executar.setForeground(new java.awt.Color(45,45,45));
        executar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                executarActionPerformed(evt);
            }
        });
        add(executar);
        executar.setBounds(260, 570, 240, 35);
        voltar.setText("Voltar");
        voltar.setFont(new java.awt.Font("Dialog", 0, 14));
        voltar.setBackground(new java.awt.Color(232,232,232));
        voltar.setOpaque(true);
        voltar.setForeground(new java.awt.Color(45,45,45));
        voltar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                voltarActionPerformed(evt);
            }
        });
        add(voltar);
        voltar.setBounds(740, 570, 180, 35);
        navInclusao.setText("Incluir");
        navInclusao.setFont(new java.awt.Font("Dialog", 0, 14));
        navInclusao.setBackground(new java.awt.Color(232,232,232));
        navInclusao.setOpaque(true);
        navInclusao.setForeground(new java.awt.Color(45,45,45));
        navInclusao.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                navInclusaoActionPerformed(evt);
            }
        });
        add(navInclusao);
        navInclusao.setBounds(260, 120, 155, 35);
        navConsulta.setText("Consultar");
        navConsulta.setFont(new java.awt.Font("Dialog", 0, 14));
        navConsulta.setBackground(new java.awt.Color(232,232,232));
        navConsulta.setOpaque(true);
        navConsulta.setForeground(new java.awt.Color(45,45,45));
        navConsulta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                navConsultaActionPerformed(evt);
            }
        });
        add(navConsulta);
        navConsulta.setBounds(427, 120, 155, 35);
        navAlteracao.setText("Alterar");
        navAlteracao.setFont(new java.awt.Font("Dialog", 0, 14));
        navAlteracao.setBackground(new java.awt.Color(232,232,232));
        navAlteracao.setOpaque(true);
        navAlteracao.setForeground(new java.awt.Color(45,45,45));
        navAlteracao.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                navAlteracaoActionPerformed(evt);
            }
        });
        add(navAlteracao);
        navAlteracao.setBounds(594, 120, 155, 35);
        navExclusao.setText("Excluir");
        navExclusao.setFont(new java.awt.Font("Dialog", 0, 14));
        navExclusao.setBackground(new java.awt.Color(232,232,232));
        navExclusao.setOpaque(true);
        navExclusao.setForeground(new java.awt.Color(45,45,45));
        navExclusao.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                navExclusaoActionPerformed(evt);
            }
        });
        add(navExclusao);
        navExclusao.setBounds(761, 120, 155, 35);
        marca.setText("");
        marca.setFont(new java.awt.Font("Dialog", 0, 32));
        marca.setForeground(new java.awt.Color(45,45,45));
        add(marca);
        marca.setBounds(24, 30, 170, 50);
        legendaMarca.setText("Controle de obras");
        legendaMarca.setFont(new java.awt.Font("Dialog", 0, 14));
        legendaMarca.setForeground(new java.awt.Color(45,45,45));
        add(legendaMarca);
        legendaMarca.setBounds(24, 85, 180, 28);
        lateralFases.setText("Fases");
        lateralFases.setFont(new java.awt.Font("Dialog", 0, 14));
        lateralFases.setBackground(new java.awt.Color(232,232,232));
        lateralFases.setOpaque(true);
        lateralFases.setForeground(new java.awt.Color(45,45,45));
        lateralFases.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                lateralFasesActionPerformed(evt);
            }
        });
        add(lateralFases);
        lateralFases.setBounds(18, 160, 174, 35);
        lateralEngenheiros.setText("Engenheiros");
        lateralEngenheiros.setFont(new java.awt.Font("Dialog", 0, 14));
        lateralEngenheiros.setBackground(new java.awt.Color(232,232,232));
        lateralEngenheiros.setOpaque(true);
        lateralEngenheiros.setForeground(new java.awt.Color(45,45,45));
        lateralEngenheiros.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                lateralEngenheirosActionPerformed(evt);
            }
        });
        add(lateralEngenheiros);
        lateralEngenheiros.setBounds(18, 216, 174, 35);
        lateralFuncoes.setText("Funções");
        lateralFuncoes.setFont(new java.awt.Font("Dialog", 0, 14));
        lateralFuncoes.setBackground(new java.awt.Color(232,232,232));
        lateralFuncoes.setOpaque(true);
        lateralFuncoes.setForeground(new java.awt.Color(45,45,45));
        lateralFuncoes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                lateralFuncoesActionPerformed(evt);
            }
        });
        add(lateralFuncoes);
        lateralFuncoes.setBounds(18, 272, 174, 35);
        lateralUsuarios.setText("Usuários");
        lateralUsuarios.setFont(new java.awt.Font("Dialog", 0, 14));
        lateralUsuarios.setBackground(new java.awt.Color(205,205,205));
        lateralUsuarios.setOpaque(true);
        lateralUsuarios.setForeground(new java.awt.Color(45,45,45));
        lateralUsuarios.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                lateralUsuariosActionPerformed(evt);
            }
        });
        add(lateralUsuarios);
        lateralUsuarios.setBounds(18, 328, 174, 35);
        inicio.setText("Menu principal");
        inicio.setBackground(new java.awt.Color(232,232,232));
        inicio.setOpaque(true);
        inicio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inicioActionPerformed(evt);
            }
        });
        add(inicio);
        inicio.setBounds(18, 452, 174, 35);
        linhaTopo.setText("");
        linhaTopo.setFont(new java.awt.Font("Dialog", 0, 14));
        linhaTopo.setBackground(new java.awt.Color(205,205,205));
        linhaTopo.setOpaque(true);
        add(linhaTopo);
        linhaTopo.setBounds(260, 96, 660, 4);
        rodape.setText("Balança Mais Não Cai");
        rodape.setFont(new java.awt.Font("Dialog", 0, 12));
        rodape.setForeground(new java.awt.Color(45,45,45));
        add(rodape);
        rodape.setBounds(260, 610, 650, 25);
        fundoLateral.setText("");
        fundoLateral.setFont(new java.awt.Font("Dialog", 0, 14));
        fundoLateral.setBackground(new java.awt.Color(218,218,218));
        fundoLateral.setOpaque(true);
        add(fundoLateral);
        fundoLateral.setBounds(0, 0, 210, 660);
    }// </editor-fold>//GEN-END:initComponents

    private void executarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_executarActionPerformed
        int linha = tabela.getSelectedRow(); if (linha < 0) { App.aviso("Selecione um registro na tabela."); return; } String[] registro = registros.get(linha); App.registro = registro; App.abrir("TelaEdicaoUsuarios");
    }//GEN-LAST:event_executarActionPerformed

    private void voltarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_voltarActionPerformed
        App.abrir("TelaManutencaoUsuarios");
    }//GEN-LAST:event_voltarActionPerformed

    private void navInclusaoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_navInclusaoActionPerformed
        App.abrir("TelaInclusaoUsuarios");
    }//GEN-LAST:event_navInclusaoActionPerformed

    private void navConsultaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_navConsultaActionPerformed
        App.abrir("TelaConsultaUsuarios");
    }//GEN-LAST:event_navConsultaActionPerformed

    private void navAlteracaoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_navAlteracaoActionPerformed
        App.abrir("TelaAlteracaoUsuarios");
    }//GEN-LAST:event_navAlteracaoActionPerformed

    private void navExclusaoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_navExclusaoActionPerformed
        App.abrir("TelaExclusaoUsuarios");
    }//GEN-LAST:event_navExclusaoActionPerformed

    private void lateralFasesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_lateralFasesActionPerformed
        App.abrir("TelaManutencaoFases");
    }//GEN-LAST:event_lateralFasesActionPerformed

    private void lateralEngenheirosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_lateralEngenheirosActionPerformed
        App.abrir("TelaManutencaoEngenheiros");
    }//GEN-LAST:event_lateralEngenheirosActionPerformed

    private void lateralFuncoesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_lateralFuncoesActionPerformed
        App.abrir("TelaManutencaoFuncoes");
    }//GEN-LAST:event_lateralFuncoesActionPerformed

    private void lateralUsuariosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_lateralUsuariosActionPerformed
        App.abrir("TelaManutencaoUsuarios");
    }//GEN-LAST:event_lateralUsuariosActionPerformed

    private void inicioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inicioActionPerformed
        App.abrir("TelaMenu");
    }//GEN-LAST:event_inicioActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel titulo;
    private javax.swing.JScrollPane rolagem;
    private javax.swing.JLabel instrucao;
    private javax.swing.JButton executar;
    private javax.swing.JButton voltar;
    private javax.swing.JButton navInclusao;
    private javax.swing.JButton navConsulta;
    private javax.swing.JButton navAlteracao;
    private javax.swing.JButton navExclusao;
    private javax.swing.JLabel marca;
    private javax.swing.JLabel legendaMarca;
    private javax.swing.JButton lateralFases;
    private javax.swing.JButton lateralEngenheiros;
    private javax.swing.JButton lateralFuncoes;
    private javax.swing.JButton lateralUsuarios;
    private javax.swing.JButton inicio;
    private javax.swing.JLabel linhaTopo;
    private javax.swing.JLabel rodape;
    private javax.swing.JLabel fundoLateral;
    private javax.swing.JTable tabela;
    // End of variables declaration//GEN-END:variables
}
