package beni.balanca.naocai;

/** Tela editável na aba Design do NetBeans. */
public class TelaLogin extends javax.swing.JPanel {
    public TelaLogin() {
        initComponents();
        
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        titulo = new javax.swing.JLabel();
        rotuloEmail = new javax.swing.JLabel();
        email = new javax.swing.JTextField();
        rotuloSenha = new javax.swing.JLabel();
        senha = new javax.swing.JPasswordField();
        entrar = new javax.swing.JButton();
        cancelar = new javax.swing.JButton();
        textoAcesso = new javax.swing.JLabel();
        marcaLogin = new javax.swing.JLabel();
        nomeLogin = new javax.swing.JLabel();
        descricaoLogin = new javax.swing.JLabel();
        faixaLogin = new javax.swing.JLabel();
        fundoLogin = new javax.swing.JLabel();

        setPreferredSize(new java.awt.Dimension(980, 660));
        setLayout(null);

        titulo.setText("Acesso ao sistema");
        titulo.setFont(new java.awt.Font("Dialog", 0, 23)); // NOI18N
        titulo.setForeground(new java.awt.Color(45, 45, 45));
        add(titulo);
        titulo.setBounds(470, 100, 440, 45);

        rotuloEmail.setText("Usuário (e-mail):");
        rotuloEmail.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        add(rotuloEmail);
        rotuloEmail.setBounds(470, 210, 360, 25);

        email.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        add(email);
        email.setBounds(470, 240, 360, 38);

        rotuloSenha.setText("Senha:");
        rotuloSenha.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        add(rotuloSenha);
        rotuloSenha.setBounds(470, 300, 360, 25);

        senha.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        add(senha);
        senha.setBounds(470, 330, 360, 38);

        entrar.setText("ENTRAR");
        entrar.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        entrar.setBackground(new java.awt.Color(205, 205, 205));
        entrar.setForeground(new java.awt.Color(45, 45, 45));
        entrar.setOpaque(true);
        entrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                entrarActionPerformed(evt);
            }
        });
        add(entrar);
        entrar.setBounds(470, 410, 220, 44);

        cancelar.setText("APAGAR");
        cancelar.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        cancelar.setBackground(new java.awt.Color(232, 232, 232));
        cancelar.setForeground(new java.awt.Color(45, 45, 45));
        cancelar.setOpaque(true);
        cancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cancelarActionPerformed(evt);
            }
        });
        add(cancelar);
        cancelar.setBounds(705, 410, 125, 44);

        textoAcesso.setText("Informe suas credenciais para continuar.");
        textoAcesso.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        textoAcesso.setForeground(new java.awt.Color(45, 45, 45));
        add(textoAcesso);
        textoAcesso.setBounds(470, 155, 400, 25);

        marcaLogin.setFont(new java.awt.Font("Dialog", 0, 48)); // NOI18N
        marcaLogin.setForeground(new java.awt.Color(45, 45, 45));
        add(marcaLogin);
        marcaLogin.setBounds(48, 150, 300, 70);

        nomeLogin.setText("Balança Mais Não Cai");
        nomeLogin.setFont(new java.awt.Font("Dialog", 0, 21)); // NOI18N
        nomeLogin.setForeground(new java.awt.Color(45, 45, 45));
        add(nomeLogin);
        nomeLogin.setBounds(48, 235, 320, 35);

        descricaoLogin.setText("Controle de obras e cadastros");
        descricaoLogin.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        descricaoLogin.setForeground(new java.awt.Color(45, 45, 45));
        add(descricaoLogin);
        descricaoLogin.setBounds(48, 280, 310, 30);

        faixaLogin.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        faixaLogin.setBackground(new java.awt.Color(205, 205, 205));
        faixaLogin.setOpaque(true);
        add(faixaLogin);
        faixaLogin.setBounds(48, 330, 85, 6);

        fundoLogin.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        fundoLogin.setBackground(new java.awt.Color(218, 218, 218));
        fundoLogin.setOpaque(true);
        add(fundoLogin);
        fundoLogin.setBounds(0, 0, 395, 660);
    }// </editor-fold>//GEN-END:initComponents

    private void entrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_entrarActionPerformed
        App.entrar(email.getText(), new String(senha.getPassword()));
    }//GEN-LAST:event_entrarActionPerformed

    private void cancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cancelarActionPerformed
        email.setText(""); senha.setText("");
    }//GEN-LAST:event_cancelarActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton cancelar;
    private javax.swing.JLabel descricaoLogin;
    private javax.swing.JTextField email;
    private javax.swing.JButton entrar;
    private javax.swing.JLabel faixaLogin;
    private javax.swing.JLabel fundoLogin;
    private javax.swing.JLabel marcaLogin;
    private javax.swing.JLabel nomeLogin;
    private javax.swing.JLabel rotuloEmail;
    private javax.swing.JLabel rotuloSenha;
    private javax.swing.JPasswordField senha;
    private javax.swing.JLabel textoAcesso;
    private javax.swing.JLabel titulo;
    // End of variables declaration//GEN-END:variables
}
