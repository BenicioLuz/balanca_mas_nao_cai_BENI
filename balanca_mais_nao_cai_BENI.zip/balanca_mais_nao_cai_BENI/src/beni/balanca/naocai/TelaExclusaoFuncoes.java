package beni.balanca.naocai;

/** Tela editável na aba Design do NetBeans. */
public class TelaExclusaoFuncoes extends javax.swing.JPanel {
    public TelaExclusaoFuncoes() {
        initComponents();
        carregar();
    }
    private java.util.List<String[]> registros;
    private void carregar() {
        if (App.dados == null) return;
        registros = App.dados.listar(2);
        javax.swing.table.DefaultTableModel modelo = new javax.swing.table.DefaultTableModel(new String[] {"Código", "Descrição da função"}, 0) { public boolean isCellEditable(int r, int c) { return false; } };
        for (String[] r : registros) modelo.addRow(java.util.Arrays.copyOf(r, 2));
        tabela.setModel(modelo); tabela.setRowHeight(28); tabela.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION); tabela.getTableHeader().setReorderingAllowed(false);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        titulo = new javax.swing.JLabel();
        rolagem = new javax.swing.JScrollPane();
        tabela = new javax.swing.JTable();
        instrucao = new javax.swing.JLabel();
        executar = new javax.swing.JButton();
        voltar = new javax.swing.JButton();
        navInclusao = new javax.swing.JButton();
        navConsulta = new javax.swing.JButton();
        navAlteracao = new javax.swing.JButton();
        navExclusao = new javax.swing.JButton();
        marca = new javax.swing.JLabel();
        legendaMarca = new javax.swing.JLabel();
        lateralFases = new javax.swing.JButton();
        lateralEngenheiros = new javax.swing.JButton();
        lateralFuncoes = new javax.swing.JButton();
        lateralUsuarios = new javax.swing.JButton();
        inicio = new javax.swing.JButton();
        linhaTopo = new javax.swing.JLabel();
        rodape = new javax.swing.JLabel();
        fundoLateral = new javax.swing.JLabel();

        setPreferredSize(new java.awt.Dimension(980, 660));
        setLayout(null);

        titulo.setText("Exclusão de Funções");
        titulo.setFont(new java.awt.Font("Dialog", 0, 23)); // NOI18N
        titulo.setForeground(new java.awt.Color(45, 45, 45));
        add(titulo);
        titulo.setBounds(260, 44, 680, 38);

        rolagem.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        rolagem.setViewportView(tabela);

        add(rolagem);
        rolagem.setBounds(260, 185, 660, 340);

        instrucao.setText("Selecione uma linha e clique no botão abaixo.");
        instrucao.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        add(instrucao);
        instrucao.setBounds(260, 535, 660, 25);

        executar.setText("Excluir selecionado");
        executar.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        executar.setBackground(new java.awt.Color(220, 220, 220));
        executar.setForeground(new java.awt.Color(45, 45, 45));
        executar.setOpaque(true);
        executar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                executarActionPerformed(evt);
            }
        });
        add(executar);
        executar.setBounds(260, 570, 240, 35);

        voltar.setText("Voltar");
        voltar.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        voltar.setBackground(new java.awt.Color(232, 232, 232));
        voltar.setForeground(new java.awt.Color(45, 45, 45));
        voltar.setOpaque(true);
        voltar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                voltarActionPerformed(evt);
            }
        });
        add(voltar);
        voltar.setBounds(740, 570, 180, 35);

        navInclusao.setText("Incluir");
        navInclusao.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        navInclusao.setBackground(new java.awt.Color(232, 232, 232));
        navInclusao.setForeground(new java.awt.Color(45, 45, 45));
        navInclusao.setOpaque(true);
        navInclusao.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                navInclusaoActionPerformed(evt);
            }
        });
        add(navInclusao);
        navInclusao.setBounds(260, 120, 155, 35);

        navConsulta.setText("Consultar");
        navConsulta.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        navConsulta.setBackground(new java.awt.Color(232, 232, 232));
        navConsulta.setForeground(new java.awt.Color(45, 45, 45));
        navConsulta.setOpaque(true);
        navConsulta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                navConsultaActionPerformed(evt);
            }
        });
        add(navConsulta);
        navConsulta.setBounds(427, 120, 155, 35);

        navAlteracao.setText("Alterar");
        navAlteracao.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        navAlteracao.setBackground(new java.awt.Color(232, 232, 232));
        navAlteracao.setForeground(new java.awt.Color(45, 45, 45));
        navAlteracao.setOpaque(true);
        navAlteracao.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                navAlteracaoActionPerformed(evt);
            }
        });
        add(navAlteracao);
        navAlteracao.setBounds(594, 120, 155, 35);

        navExclusao.setText("Excluir");
        navExclusao.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        navExclusao.setBackground(new java.awt.Color(232, 232, 232));
        navExclusao.setForeground(new java.awt.Color(45, 45, 45));
        navExclusao.setOpaque(true);
        navExclusao.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                navExclusaoActionPerformed(evt);
            }
        });
        add(navExclusao);
        navExclusao.setBounds(761, 120, 155, 35);

        marca.setFont(new java.awt.Font("Dialog", 0, 32)); // NOI18N
        marca.setForeground(new java.awt.Color(45, 45, 45));
        add(marca);
        marca.setBounds(24, 30, 170, 50);

        legendaMarca.setText("Controle de obras");
        legendaMarca.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        legendaMarca.setForeground(new java.awt.Color(45, 45, 45));
        add(legendaMarca);
        legendaMarca.setBounds(24, 85, 180, 28);

        lateralFases.setText("Fases");
        lateralFases.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        lateralFases.setBackground(new java.awt.Color(232, 232, 232));
        lateralFases.setForeground(new java.awt.Color(45, 45, 45));
        lateralFases.setOpaque(true);
        lateralFases.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                lateralFasesActionPerformed(evt);
            }
        });
        add(lateralFases);
        lateralFases.setBounds(18, 160, 174, 35);

        lateralEngenheiros.setText("Engenheiros");
        lateralEngenheiros.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        lateralEngenheiros.setBackground(new java.awt.Color(232, 232, 232));
        lateralEngenheiros.setForeground(new java.awt.Color(45, 45, 45));
        lateralEngenheiros.setOpaque(true);
        lateralEngenheiros.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                lateralEngenheirosActionPerformed(evt);
            }
        });
        add(lateralEngenheiros);
        lateralEngenheiros.setBounds(18, 216, 174, 35);

        lateralFuncoes.setText("Funções");
        lateralFuncoes.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        lateralFuncoes.setBackground(new java.awt.Color(205, 205, 205));
        lateralFuncoes.setForeground(new java.awt.Color(45, 45, 45));
        lateralFuncoes.setOpaque(true);
        lateralFuncoes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                lateralFuncoesActionPerformed(evt);
            }
        });
        add(lateralFuncoes);
        lateralFuncoes.setBounds(18, 272, 174, 35);

        lateralUsuarios.setText("Usuários");
        lateralUsuarios.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        lateralUsuarios.setBackground(new java.awt.Color(232, 232, 232));
        lateralUsuarios.setForeground(new java.awt.Color(45, 45, 45));
        lateralUsuarios.setOpaque(true);
        lateralUsuarios.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                lateralUsuariosActionPerformed(evt);
            }
        });
        add(lateralUsuarios);
        lateralUsuarios.setBounds(18, 328, 174, 35);

        inicio.setText("Menu principal");
        inicio.setBackground(new java.awt.Color(232, 232, 232));
        inicio.setOpaque(true);
        inicio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inicioActionPerformed(evt);
            }
        });
        add(inicio);
        inicio.setBounds(18, 452, 174, 35);

        linhaTopo.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        linhaTopo.setBackground(new java.awt.Color(205, 205, 205));
        linhaTopo.setOpaque(true);
        add(linhaTopo);
        linhaTopo.setBounds(260, 96, 660, 4);

        rodape.setText("Balança Mais Não Cai");
        rodape.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        rodape.setForeground(new java.awt.Color(45, 45, 45));
        add(rodape);
        rodape.setBounds(260, 610, 650, 25);

        fundoLateral.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        fundoLateral.setBackground(new java.awt.Color(218, 218, 218));
        fundoLateral.setOpaque(true);
        add(fundoLateral);
        fundoLateral.setBounds(0, 0, 210, 660);
    }// </editor-fold>//GEN-END:initComponents

    private void executarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_executarActionPerformed
        int linha = tabela.getSelectedRow(); if (linha < 0) { App.aviso("Selecione um registro na tabela."); return; } String[] registro = registros.get(linha); if (2 == 3 && App.usuario != null && App.usuario[0].equals(registro[0])) { App.aviso("Não é possível excluir o usuário conectado."); return; } if (javax.swing.JOptionPane.showConfirmDialog(this, "Excluir " + registro[1] + "?", "Confirmar exclusão", javax.swing.JOptionPane.YES_NO_OPTION) == javax.swing.JOptionPane.YES_OPTION) { try { App.dados.excluir(2, Integer.parseInt(registro[0])); carregar(); } catch (Exception ex) { App.aviso(ex.getMessage()); } }
    }//GEN-LAST:event_executarActionPerformed

    private void voltarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_voltarActionPerformed
        App.abrir("TelaManutencaoFuncoes");
    }//GEN-LAST:event_voltarActionPerformed

    private void navInclusaoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_navInclusaoActionPerformed
        App.abrir("TelaInclusaoFuncoes");
    }//GEN-LAST:event_navInclusaoActionPerformed

    private void navConsultaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_navConsultaActionPerformed
        App.abrir("TelaConsultaFuncoes");
    }//GEN-LAST:event_navConsultaActionPerformed

    private void navAlteracaoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_navAlteracaoActionPerformed
        App.abrir("TelaAlteracaoFuncoes");
    }//GEN-LAST:event_navAlteracaoActionPerformed

    private void navExclusaoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_navExclusaoActionPerformed
        App.abrir("TelaExclusaoFuncoes");
    }//GEN-LAST:event_navExclusaoActionPerformed

    private void lateralFasesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_lateralFasesActionPerformed
        App.abrir("TelaManutencaoFases");
    }//GEN-LAST:event_lateralFasesActionPerformed

    private void lateralEngenheirosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_lateralEngenheirosActionPerformed
        App.abrir("TelaManutencaoEngenheiros");
    }//GEN-LAST:event_lateralEngenheirosActionPerformed

    private void lateralFuncoesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_lateralFuncoesActionPerformed
        App.abrir("TelaManutencaoFuncoes");
    }//GEN-LAST:event_lateralFuncoesActionPerformed

    private void lateralUsuariosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_lateralUsuariosActionPerformed
        App.abrir("TelaManutencaoUsuarios");
    }//GEN-LAST:event_lateralUsuariosActionPerformed

    private void inicioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inicioActionPerformed
        App.abrir("TelaMenu");
    }//GEN-LAST:event_inicioActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton executar;
    private javax.swing.JLabel fundoLateral;
    private javax.swing.JButton inicio;
    private javax.swing.JLabel instrucao;
    private javax.swing.JButton lateralEngenheiros;
    private javax.swing.JButton lateralFases;
    private javax.swing.JButton lateralFuncoes;
    private javax.swing.JButton lateralUsuarios;
    private javax.swing.JLabel legendaMarca;
    private javax.swing.JLabel linhaTopo;
    private javax.swing.JLabel marca;
    private javax.swing.JButton navAlteracao;
    private javax.swing.JButton navConsulta;
    private javax.swing.JButton navExclusao;
    private javax.swing.JButton navInclusao;
    private javax.swing.JLabel rodape;
    private javax.swing.JScrollPane rolagem;
    private javax.swing.JTable tabela;
    private javax.swing.JLabel titulo;
    private javax.swing.JButton voltar;
    // End of variables declaration//GEN-END:variables
}
