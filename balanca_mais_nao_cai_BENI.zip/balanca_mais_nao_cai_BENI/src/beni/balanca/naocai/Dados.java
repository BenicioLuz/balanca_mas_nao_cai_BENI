package beni.balanca.naocai;

import java.io.*;
import java.nio.file.*;
import java.security.*;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.time.format.*;
import java.util.*;

/** Persistência local em Properties XML. Não depende de servidor ou biblioteca externa. */
public final class Dados {
    public static final String[] TIPOS = {"Fases", "Engenheiros", "Funções", "Usuários"};
    public static final String[][] CAMPOS = {{"Descrição da Fase"}, {"Nome do Engenheiro", "CREA", "Data de Admissão"}, {"Descrição da Função"}, {"Nome", "E-mail", "Senha"}};
    private final Path arquivo;
    private Properties dados = new Properties();
    public Dados(Path arquivo) throws IOException {
        this.arquivo = arquivo;
        if (Files.exists(arquivo)) {
            try (InputStream in = Files.newInputStream(arquivo)) { dados.loadFromXML(in); }
        } else {
            inserir(0, "Planejamento");
            inserir(1, "João Silva", "SC-123456", "10/01/2024");
            inserir(2, "Mestre de obras");
            inserir(3, "Usuario Teste", "teste@email.com.br", "12345");
        }
    }
    public java.util.List<String[]> listar(int tipo) {
        java.util.List<String[]> linhas = new ArrayList<>();
        int ultimo = Integer.parseInt(dados.getProperty(tipo + ".ultimo", "0"));
        for (int id = 1; id <= ultimo; id++) {
            String prefixo = tipo + "." + id + ".";
            if (!dados.containsKey(prefixo + "0")) continue;
            String[] linha = new String[CAMPOS[tipo].length + 1]; linha[0] = "" + id;
            for (int c = 1; c < linha.length; c++) linha[c] = dados.getProperty(prefixo + (c - 1), "");
            linhas.add(linha);
        }
        return linhas;
    }
    public void inserir(int tipo, String... valores) throws IOException {
        int id = Integer.parseInt(dados.getProperty(tipo + ".ultimo", "0")) + 1;
        gravar(tipo, id, valores, true);
    }
    /** Código informado no formulário de fases. Os demais cadastros usam código automático. */
    public void inserirFase(String codigo, String descricao) throws IOException {
        int id;
        try { id = Integer.parseInt(codigo.trim()); }
        catch (NumberFormatException ex) { throw new IllegalArgumentException("Informe um código numérico para a fase."); }
        if (id < 1 || id > 99999) throw new IllegalArgumentException("O código deve estar entre 1 e 99999.");
        if (dados.containsKey("0." + id + ".0")) throw new IllegalArgumentException("Este código de fase já existe.");
        gravar(0, id, new String[] {descricao}, true);
    }
    public void alterar(int tipo, int id, String... valores) throws IOException { gravar(tipo, id, valores, false); }
    private void gravar(int tipo, int id, String[] valores, boolean novo) throws IOException {
        String[] v = valores.clone();
        for (int i = 0; i < v.length; i++) {
            v[i] = v[i].trim();
            if (v[i].isEmpty() && !(tipo == 3 && i == 2 && !novo)) throw new IllegalArgumentException("Preencha todos os campos.");
        }
        if (tipo == 1) {
            try { LocalDate.parse(v[2], DateTimeFormatter.ofPattern("dd/MM/uuuu").withResolverStyle(ResolverStyle.STRICT)); }
            catch (DateTimeParseException e) { throw new IllegalArgumentException("Informe uma data válida no formato dd/mm/aaaa."); }
        }
        if (tipo == 3) {
            if (!v[1].matches("[^\\s@]+@[^\\s@]+\\.[^\\s@]+")) throw new IllegalArgumentException("Informe um e-mail válido.");
            for (String[] r : listar(3)) if (Integer.parseInt(r[0]) != id && r[2].equalsIgnoreCase(v[1])) throw new IllegalArgumentException("Este e-mail já está cadastrado.");
            v[2] = v[2].isEmpty() ? dados.getProperty("3." + id + ".2") : senha(v[2]);
        }
        Properties copia = (Properties) dados.clone();
        if (novo) copia.setProperty(tipo + ".ultimo", "" + Math.max(id, Integer.parseInt(dados.getProperty(tipo + ".ultimo", "0"))));
        for (int c = 0; c < v.length; c++) copia.setProperty(tipo + "." + id + "." + c, v[c]);
        salvar(copia);
    }
    public void excluir(int tipo, int id) throws IOException {
        Properties copia = (Properties) dados.clone();
        for (int c = 0; c < CAMPOS[tipo].length; c++) copia.remove(tipo + "." + id + "." + c);
        salvar(copia);
    }
    public String[] autenticar(String email, String senha) {
        for (String[] r : listar(3)) if (r[2].equalsIgnoreCase(email.trim()) && confere(senha, r[3])) return r;
        return null;
    }
    private static String senha(String texto) {
        byte[] sal = new byte[16]; new SecureRandom().nextBytes(sal);
        String s = Base64.getEncoder().encodeToString(sal);
        return s + ":" + hash(s, texto);
    }
    private static String hash(String sal, String texto) {
        try {
            javax.crypto.spec.PBEKeySpec spec = new javax.crypto.spec.PBEKeySpec(texto.toCharArray(), Base64.getDecoder().decode(sal), 65536, 256);
            byte[] bytes = javax.crypto.SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).getEncoded();
            spec.clearPassword(); return Base64.getEncoder().encodeToString(bytes);
        } catch (GeneralSecurityException e) { throw new IllegalStateException(e); }
    }
    private static boolean confere(String texto, String salvo) {
        String[] partes = salvo.split(":", 2);
        return partes.length == 2 && MessageDigest.isEqual(hash(partes[0], texto).getBytes(StandardCharsets.UTF_8), partes[1].getBytes(StandardCharsets.UTF_8));
    }
    private void salvar(Properties copia) throws IOException {
        Path destino = arquivo.toAbsolutePath(); Files.createDirectories(destino.getParent());
        Path temporario = Files.createTempFile(destino.getParent(), "cadastros-", ".tmp");
        try {
            try (OutputStream out = Files.newOutputStream(temporario)) { copia.storeToXML(out, "Balança-Mas-Não-Cai", "UTF-8"); }
            try { Files.move(temporario, destino, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (AtomicMoveNotSupportedException e) { Files.move(temporario, destino, StandardCopyOption.REPLACE_EXISTING); }
            dados = copia;
        } finally { Files.deleteIfExists(temporario); }
    }
}
