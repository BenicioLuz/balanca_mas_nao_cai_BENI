package beni.balanca.naocai;

/** Tela editável na aba Design do NetBeans. */
public class TelaMenu extends javax.swing.JPanel {
    public TelaMenu() {
        initComponents();
        if (App.usuario != null) titulo.setText("Seja bem-vindo(a), " + App.usuario[1]);
        
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        titulo = new javax.swing.JLabel();
        abrirFases = new javax.swing.JButton();
        abrirEngenheiros = new javax.swing.JButton();
        abrirFuncoes = new javax.swing.JButton();
        abrirUsuarios = new javax.swing.JButton();
        sair = new javax.swing.JButton();
        marca = new javax.swing.JLabel();
        legendaMarca = new javax.swing.JLabel();
        lateralFases = new javax.swing.JButton();
        lateralEngenheiros = new javax.swing.JButton();
        lateralFuncoes = new javax.swing.JButton();
        lateralUsuarios = new javax.swing.JButton();
        inicio = new javax.swing.JButton();
        linhaTopo = new javax.swing.JLabel();
        rodape = new javax.swing.JLabel();
        intro = new javax.swing.JLabel();
        fundoLateral = new javax.swing.JLabel();

        setPreferredSize(new java.awt.Dimension(980, 660));
        setLayout(null);

        titulo.setText("Central de cadastros");
        titulo.setFont(new java.awt.Font("Dialog", 0, 23)); // NOI18N
        titulo.setForeground(new java.awt.Color(45, 45, 45));
        add(titulo);
        titulo.setBounds(260, 44, 680, 38);

        abrirFases.setBackground(new java.awt.Color(205, 205, 205));
        abrirFases.setFont(new java.awt.Font("Dialog", 0, 19)); // NOI18N
        abrirFases.setForeground(new java.awt.Color(45, 45, 45));
        abrirFases.setText("01   Fases da obra");
        abrirFases.setOpaque(true);
        abrirFases.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                abrirFasesActionPerformed(evt);
            }
        });
        add(abrirFases);
        abrirFases.setBounds(260, 190, 315, 100);

        abrirEngenheiros.setText("02   Engenheiros");
        abrirEngenheiros.setFont(new java.awt.Font("Dialog", 0, 19)); // NOI18N
        abrirEngenheiros.setBackground(new java.awt.Color(232, 232, 232));
        abrirEngenheiros.setForeground(new java.awt.Color(45, 45, 45));
        abrirEngenheiros.setOpaque(true);
        abrirEngenheiros.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                abrirEngenheirosActionPerformed(evt);
            }
        });
        add(abrirEngenheiros);
        abrirEngenheiros.setBounds(600, 190, 315, 100);

        abrirFuncoes.setText("03   Funções");
        abrirFuncoes.setFont(new java.awt.Font("Dialog", 0, 19)); // NOI18N
        abrirFuncoes.setBackground(new java.awt.Color(232, 232, 232));
        abrirFuncoes.setForeground(new java.awt.Color(45, 45, 45));
        abrirFuncoes.setOpaque(true);
        abrirFuncoes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                abrirFuncoesActionPerformed(evt);
            }
        });
        add(abrirFuncoes);
        abrirFuncoes.setBounds(260, 320, 315, 100);

        abrirUsuarios.setText("04   Usuários");
        abrirUsuarios.setFont(new java.awt.Font("Dialog", 0, 19)); // NOI18N
        abrirUsuarios.setBackground(new java.awt.Color(232, 232, 232));
        abrirUsuarios.setForeground(new java.awt.Color(45, 45, 45));
        abrirUsuarios.setOpaque(true);
        abrirUsuarios.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                abrirUsuariosActionPerformed(evt);
            }
        });
        add(abrirUsuarios);
        abrirUsuarios.setBounds(600, 320, 315, 100);

        sair.setText("Sair do sistema");
        sair.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        sair.setBackground(new java.awt.Color(232, 232, 232));
        sair.setForeground(new java.awt.Color(45, 45, 45));
        sair.setOpaque(true);
        sair.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                sairActionPerformed(evt);
            }
        });
        add(sair);
        sair.setBounds(710, 520, 205, 40);

        marca.setFont(new java.awt.Font("Dialog", 0, 32)); // NOI18N
        marca.setForeground(new java.awt.Color(45, 45, 45));
        add(marca);
        marca.setBounds(24, 30, 170, 50);

        legendaMarca.setText("Controle de obras");
        legendaMarca.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        legendaMarca.setForeground(new java.awt.Color(45, 45, 45));
        add(legendaMarca);
        legendaMarca.setBounds(24, 85, 180, 28);

        lateralFases.setText("Fases");
        lateralFases.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        lateralFases.setBackground(new java.awt.Color(232, 232, 232));
        lateralFases.setForeground(new java.awt.Color(45, 45, 45));
        lateralFases.setOpaque(true);
        lateralFases.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                lateralFasesActionPerformed(evt);
            }
        });
        add(lateralFases);
        lateralFases.setBounds(18, 160, 174, 35);

        lateralEngenheiros.setText("Engenheiros");
        lateralEngenheiros.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        lateralEngenheiros.setBackground(new java.awt.Color(232, 232, 232));
        lateralEngenheiros.setForeground(new java.awt.Color(45, 45, 45));
        lateralEngenheiros.setOpaque(true);
        lateralEngenheiros.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                lateralEngenheirosActionPerformed(evt);
            }
        });
        add(lateralEngenheiros);
        lateralEngenheiros.setBounds(18, 216, 174, 35);

        lateralFuncoes.setText("Funções");
        lateralFuncoes.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        lateralFuncoes.setBackground(new java.awt.Color(232, 232, 232));
        lateralFuncoes.setForeground(new java.awt.Color(45, 45, 45));
        lateralFuncoes.setOpaque(true);
        lateralFuncoes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                lateralFuncoesActionPerformed(evt);
            }
        });
        add(lateralFuncoes);
        lateralFuncoes.setBounds(18, 272, 174, 35);

        lateralUsuarios.setText("Usuários");
        lateralUsuarios.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        lateralUsuarios.setBackground(new java.awt.Color(232, 232, 232));
        lateralUsuarios.setForeground(new java.awt.Color(45, 45, 45));
        lateralUsuarios.setOpaque(true);
        lateralUsuarios.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                lateralUsuariosActionPerformed(evt);
            }
        });
        add(lateralUsuarios);
        lateralUsuarios.setBounds(18, 328, 174, 35);

        inicio.setText("Menu principal");
        inicio.setBackground(new java.awt.Color(232, 232, 232));
        inicio.setOpaque(true);
        inicio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inicioActionPerformed(evt);
            }
        });
        add(inicio);
        inicio.setBounds(18, 452, 174, 35);

        linhaTopo.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        linhaTopo.setBackground(new java.awt.Color(205, 205, 205));
        linhaTopo.setOpaque(true);
        add(linhaTopo);
        linhaTopo.setBounds(260, 96, 660, 4);

        rodape.setText("Balança Mais Não Cai");
        rodape.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        rodape.setForeground(new java.awt.Color(45, 45, 45));
        add(rodape);
        rodape.setBounds(260, 610, 650, 25);

        intro.setText("Escolha uma área para começar.");
        intro.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        intro.setForeground(new java.awt.Color(45, 45, 45));
        add(intro);
        intro.setBounds(260, 112, 620, 30);

        fundoLateral.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        fundoLateral.setBackground(new java.awt.Color(218, 218, 218));
        fundoLateral.setOpaque(true);
        add(fundoLateral);
        fundoLateral.setBounds(0, 0, 210, 660);
    }// </editor-fold>//GEN-END:initComponents

    private void abrirFasesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_abrirFasesActionPerformed
        App.abrir("TelaManutencaoFases");
    }//GEN-LAST:event_abrirFasesActionPerformed

    private void abrirEngenheirosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_abrirEngenheirosActionPerformed
        App.abrir("TelaManutencaoEngenheiros");
    }//GEN-LAST:event_abrirEngenheirosActionPerformed

    private void abrirFuncoesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_abrirFuncoesActionPerformed
        App.abrir("TelaManutencaoFuncoes");
    }//GEN-LAST:event_abrirFuncoesActionPerformed

    private void abrirUsuariosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_abrirUsuariosActionPerformed
        App.abrir("TelaManutencaoUsuarios");
    }//GEN-LAST:event_abrirUsuariosActionPerformed

    private void sairActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_sairActionPerformed
        App.usuario = null; App.abrir("TelaLogin");
    }//GEN-LAST:event_sairActionPerformed

    private void lateralFasesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_lateralFasesActionPerformed
        App.abrir("TelaManutencaoFases");
    }//GEN-LAST:event_lateralFasesActionPerformed

    private void lateralEngenheirosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_lateralEngenheirosActionPerformed
        App.abrir("TelaManutencaoEngenheiros");
    }//GEN-LAST:event_lateralEngenheirosActionPerformed

    private void lateralFuncoesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_lateralFuncoesActionPerformed
        App.abrir("TelaManutencaoFuncoes");
    }//GEN-LAST:event_lateralFuncoesActionPerformed

    private void lateralUsuariosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_lateralUsuariosActionPerformed
        App.abrir("TelaManutencaoUsuarios");
    }//GEN-LAST:event_lateralUsuariosActionPerformed

    private void inicioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inicioActionPerformed
        App.abrir("TelaMenu");
    }//GEN-LAST:event_inicioActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton abrirEngenheiros;
    private javax.swing.JButton abrirFases;
    private javax.swing.JButton abrirFuncoes;
    private javax.swing.JButton abrirUsuarios;
    private javax.swing.JLabel fundoLateral;
    private javax.swing.JButton inicio;
    private javax.swing.JLabel intro;
    private javax.swing.JButton lateralEngenheiros;
    private javax.swing.JButton lateralFases;
    private javax.swing.JButton lateralFuncoes;
    private javax.swing.JButton lateralUsuarios;
    private javax.swing.JLabel legendaMarca;
    private javax.swing.JLabel linhaTopo;
    private javax.swing.JLabel marca;
    private javax.swing.JLabel rodape;
    private javax.swing.JButton sair;
    private javax.swing.JLabel titulo;
    // End of variables declaration//GEN-END:variables
}
