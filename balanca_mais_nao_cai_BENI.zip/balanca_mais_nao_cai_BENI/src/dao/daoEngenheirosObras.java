package dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import model.engenheiros_obras;

public class daoEngenheirosObras extends JdbcDao {

    private engenheiros_obras mapear(ResultSet resultado) throws SQLException {
        engenheiros_obras relacao = new engenheiros_obras();
        relacao.setIdEngenheiro(resultado.getInt("idEngenheiro"));
        relacao.setIdObra(resultado.getInt("idObra"));
        relacao.setDtInicio(resultado.getDate("dtInicio"));
        relacao.setDtFim(resultado.getDate("dtFim"));
        relacao.setIdFuncao(resultado.getInt("idFuncao"));
        return relacao;
    }

    public boolean inserir(engenheiros_obras relacao) throws SQLException {
        String sql = "INSERT INTO engenheiros_obras "
                + "(idEngenheiro, idObra, dtInicio, dtFim, idFuncao) "
                + "VALUES (?, ?, ?, ?, ?)";
        return executar(sql, relacao.getIdEngenheiro(), relacao.getIdObra(),
                relacao.getDtInicio(), relacao.getDtFim(), relacao.getIdFuncao()) > 0;
    }

    public boolean atualizar(engenheiros_obras relacao) throws SQLException {
        String sql = "UPDATE engenheiros_obras SET dtInicio = ?, dtFim = ?, idFuncao = ? "
                + "WHERE idEngenheiro = ? AND idObra = ?";
        return executar(sql, relacao.getDtInicio(), relacao.getDtFim(), relacao.getIdFuncao(),
                relacao.getIdEngenheiro(), relacao.getIdObra()) > 0;
    }

    public List<engenheiros_obras> listar() throws SQLException {
        String sql = "SELECT idEngenheiro, idObra, dtInicio, dtFim, idFuncao "
                + "FROM engenheiros_obras ORDER BY idEngenheiro, idObra";
        return consultar(sql, this::mapear);
    }

    public List<engenheiros_obras> listarPorObra(int idObra) throws SQLException {
        String sql = "SELECT idEngenheiro, idObra, dtInicio, dtFim, idFuncao "
                + "FROM engenheiros_obras WHERE idObra = ? ORDER BY idEngenheiro";
        return consultar(sql, this::mapear, idObra);
    }

    public engenheiros_obras buscar(int idEngenheiro, int idObra) throws SQLException {
        String sql = "SELECT idEngenheiro, idObra, dtInicio, dtFim, idFuncao "
                + "FROM engenheiros_obras WHERE idEngenheiro = ? AND idObra = ?";
        List<engenheiros_obras> resultados = consultar(sql, this::mapear, idEngenheiro, idObra);
        return resultados.isEmpty() ? null : resultados.get(0);
    }

    public boolean excluir(int idEngenheiro, int idObra) throws SQLException {
        String sql = "DELETE FROM engenheiros_obras WHERE idEngenheiro = ? AND idObra = ?";
        return executar(sql, idEngenheiro, idObra) > 0;
    }
}
