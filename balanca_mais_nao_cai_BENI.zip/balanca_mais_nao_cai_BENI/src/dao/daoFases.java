package dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import model.fases;

public class daoFases extends JdbcDao {

    private fases mapear(ResultSet resultado) throws SQLException {
        fases fase = new fases();
        fase.setIdFase(resultado.getInt("idFase"));
        fase.setDsFase(resultado.getString("dsFase"));
        return fase;
    }

    public boolean inserir(fases fase) throws SQLException {
        return executar("INSERT INTO fases (dsFase) VALUES (?)", fase.getDsFase()) > 0;
    }

    public boolean atualizar(fases fase) throws SQLException {
        String sql = "UPDATE fases SET dsFase = ? WHERE idFase = ?";
        return executar(sql, fase.getDsFase(), fase.getIdFase()) > 0;
    }

    public List<fases> listar() throws SQLException {
        String sql = "SELECT idFase, dsFase FROM fases ORDER BY idFase";
        return consultar(sql, this::mapear);
    }

    public fases buscarPorId(int idFase) throws SQLException {
        String sql = "SELECT idFase, dsFase FROM fases WHERE idFase = ?";
        List<fases> resultados = consultar(sql, this::mapear, idFase);
        return resultados.isEmpty() ? null : resultados.get(0);
    }

    public boolean excluir(int idFase) throws SQLException {
        return executar("DELETE FROM fases WHERE idFase = ?", idFase) > 0;
    }
}
