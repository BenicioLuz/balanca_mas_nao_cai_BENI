package dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import model.obras_fases;

public class daoObrasFases extends JdbcDao {

    private obras_fases mapear(ResultSet resultado) throws SQLException {
        obras_fases relacao = new obras_fases();
        relacao.setIdObra(resultado.getInt("idObra"));
        relacao.setIdFase(resultado.getInt("idFase"));
        relacao.setDtInicio(resultado.getDate("dtInicio"));
        relacao.setDtFim(resultado.getDate("dtFim"));
        return relacao;
    }

    public boolean inserir(obras_fases relacao) throws SQLException {
        String sql = "INSERT INTO obras_fases (idObra, idFase, dtInicio, dtFim) "
                + "VALUES (?, ?, ?, ?)";
        return executar(sql, relacao.getIdObra(), relacao.getIdFase(),
                relacao.getDtInicio(), relacao.getDtFim()) > 0;
    }

    public boolean atualizar(obras_fases relacao) throws SQLException {
        String sql = "UPDATE obras_fases SET dtInicio = ?, dtFim = ? "
                + "WHERE idObra = ? AND idFase = ?";
        return executar(sql, relacao.getDtInicio(), relacao.getDtFim(),
                relacao.getIdObra(), relacao.getIdFase()) > 0;
    }

    public List<obras_fases> listar() throws SQLException {
        String sql = "SELECT idObra, idFase, dtInicio, dtFim FROM obras_fases "
                + "ORDER BY idObra, idFase";
        return consultar(sql, this::mapear);
    }

    public List<obras_fases> listarPorObra(int idObra) throws SQLException {
        String sql = "SELECT idObra, idFase, dtInicio, dtFim FROM obras_fases "
                + "WHERE idObra = ? ORDER BY idFase";
        return consultar(sql, this::mapear, idObra);
    }

    public obras_fases buscar(int idObra, int idFase) throws SQLException {
        String sql = "SELECT idObra, idFase, dtInicio, dtFim FROM obras_fases "
                + "WHERE idObra = ? AND idFase = ?";
        List<obras_fases> resultados = consultar(sql, this::mapear, idObra, idFase);
        return resultados.isEmpty() ? null : resultados.get(0);
    }

    public boolean excluir(int idObra, int idFase) throws SQLException {
        String sql = "DELETE FROM obras_fases WHERE idObra = ? AND idFase = ?";
        return executar(sql, idObra, idFase) > 0;
    }
}
