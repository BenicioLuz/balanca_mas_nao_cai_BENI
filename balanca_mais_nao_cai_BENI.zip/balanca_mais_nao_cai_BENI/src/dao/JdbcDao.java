package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/** Operações JDBC compartilhadas pelos DAOs. */
abstract class JdbcDao {

    protected Connection conectar() throws SQLException {
        Connection conexao = new DataSource().getConnection();
        if (conexao == null) {
            throw new SQLException("Não foi possível conectar ao banco de dados.");
        }
        return conexao;
    }

    protected int executar(String sql, Object... valores) throws SQLException {
        try (Connection conexao = conectar();
                PreparedStatement comando = conexao.prepareStatement(sql)) {
            preencher(comando, valores);
            return comando.executeUpdate();
        }
    }

    protected <T> List<T> consultar(
            String sql, Leitor<T> leitor, Object... valores) throws SQLException {
        List<T> itens = new ArrayList<>();

        try (Connection conexao = conectar();
                PreparedStatement comando = conexao.prepareStatement(sql)) {
            preencher(comando, valores);

            try (ResultSet resultados = comando.executeQuery()) {
                while (resultados.next()) {
                    itens.add(leitor.ler(resultados));
                }
            }
        }

        return itens;
    }

    protected static void preencher(PreparedStatement comando, Object... valores)
            throws SQLException {
        for (int indice = 0; indice < valores.length; indice++) {
            Object valor = valores[indice];
            if (valor instanceof java.util.Date) {
                java.util.Date data = (java.util.Date) valor;
                comando.setDate(indice + 1, new java.sql.Date(data.getTime()));
            } else {
                comando.setObject(indice + 1, valor);
            }
        }
    }

    @FunctionalInterface
    protected interface Leitor<T> {

        T ler(ResultSet resultado) throws SQLException;
    }
}
