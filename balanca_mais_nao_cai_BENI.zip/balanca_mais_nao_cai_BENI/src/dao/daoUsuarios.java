package dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import model.usuarios;

public class daoUsuarios extends JdbcDao {

    private usuarios mapear(ResultSet resultado) throws SQLException {
        usuarios usuario = new usuarios();
        usuario.setIdUsuario(resultado.getInt("idUsuario"));
        usuario.setNome(resultado.getString("Nome"));
        usuario.setEmail(resultado.getString("Email"));
        return usuario;
    }

    public boolean inserir(usuarios usuario) throws SQLException {
        String sql = "INSERT INTO usuarios (Nome, Email) VALUES (?, ?)";
        return executar(sql, usuario.getNome(), usuario.getEmail()) > 0;
    }

    public boolean atualizar(usuarios usuario) throws SQLException {
        String sql = "UPDATE usuarios SET Nome = ?, Email = ? WHERE idUsuario = ?";
        return executar(sql, usuario.getNome(), usuario.getEmail(), usuario.getIdUsuario()) > 0;
    }

    public List<usuarios> listar() throws SQLException {
        String sql = "SELECT idUsuario, Nome, Email FROM usuarios ORDER BY idUsuario";
        return consultar(sql, this::mapear);
    }

    public usuarios buscarPorId(int idUsuario) throws SQLException {
        String sql = "SELECT idUsuario, Nome, Email FROM usuarios WHERE idUsuario = ?";
        List<usuarios> resultados = consultar(sql, this::mapear, idUsuario);
        return resultados.isEmpty() ? null : resultados.get(0);
    }

    public boolean excluir(int idUsuario) throws SQLException {
        return executar("DELETE FROM usuarios WHERE idUsuario = ?", idUsuario) > 0;
    }
}
