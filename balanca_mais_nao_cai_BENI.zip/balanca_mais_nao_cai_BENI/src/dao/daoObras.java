package dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import model.obras;

public class daoObras extends JdbcDao {

    private obras mapear(ResultSet resultado) throws SQLException {
        obras obra = new obras();
        obra.setIdObra(resultado.getInt("idObra"));
        obra.setDescricao(resultado.getString("dsObra"));
        obra.setDtInicio(resultado.getDate("dtInicio"));
        obra.setDtFim(resultado.getDate("dtFim"));
        obra.setIdEngenheiro(resultado.getInt("idEngenheiro"));
        return obra;
    }

    public boolean inserir(obras obra) throws SQLException {
        String sql = "INSERT INTO obras (dsObra, dtInicio, dtFim, idEngenheiro) "
                + "VALUES (?, ?, ?, ?)";
        return executar(sql, obra.getDescricao(), obra.getDtInicio(),
                obra.getDtFim(), obra.getIdEngenheiro()) > 0;
    }

    public boolean atualizar(obras obra) throws SQLException {
        String sql = "UPDATE obras SET dsObra = ?, dtInicio = ?, dtFim = ?, "
                + "idEngenheiro = ? WHERE idObra = ?";
        return executar(sql, obra.getDescricao(), obra.getDtInicio(),
                obra.getDtFim(), obra.getIdEngenheiro(), obra.getIdObra()) > 0;
    }

    public List<obras> listar() throws SQLException {
        String sql = "SELECT idObra, dsObra, dtInicio, dtFim, idEngenheiro "
                + "FROM obras ORDER BY idObra";
        return consultar(sql, this::mapear);
    }

    public obras buscarPorId(int idObra) throws SQLException {
        String sql = "SELECT idObra, dsObra, dtInicio, dtFim, idEngenheiro "
                + "FROM obras WHERE idObra = ?";
        List<obras> resultados = consultar(sql, this::mapear, idObra);
        return resultados.isEmpty() ? null : resultados.get(0);
    }

    public boolean excluir(int idObra) throws SQLException {
        return executar("DELETE FROM obras WHERE idObra = ?", idObra) > 0;
    }
}
