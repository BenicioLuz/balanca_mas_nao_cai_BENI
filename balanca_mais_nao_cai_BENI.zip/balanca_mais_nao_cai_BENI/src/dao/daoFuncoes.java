package dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import model.funcoes;

public class daoFuncoes extends JdbcDao {

    private funcoes mapear(ResultSet resultado) throws SQLException {
        funcoes funcao = new funcoes();
        funcao.setIdFuncao(resultado.getInt("idFuncao"));
        funcao.setDsFuncao(resultado.getString("dsFuncao"));
        return funcao;
    }

    public boolean inserir(funcoes funcao) throws SQLException {
        return executar("INSERT INTO funcoes (dsFuncao) VALUES (?)", funcao.getDsFuncao()) > 0;
    }

    public boolean atualizar(funcoes funcao) throws SQLException {
        String sql = "UPDATE funcoes SET dsFuncao = ? WHERE idFuncao = ?";
        return executar(sql, funcao.getDsFuncao(), funcao.getIdFuncao()) > 0;
    }

    public List<funcoes> listar() throws SQLException {
        String sql = "SELECT idFuncao, dsFuncao FROM funcoes ORDER BY idFuncao";
        return consultar(sql, this::mapear);
    }

    public funcoes buscarPorId(int idFuncao) throws SQLException {
        String sql = "SELECT idFuncao, dsFuncao FROM funcoes WHERE idFuncao = ?";
        List<funcoes> resultados = consultar(sql, this::mapear, idFuncao);
        return resultados.isEmpty() ? null : resultados.get(0);
    }

    public boolean excluir(int idFuncao) throws SQLException {
        return executar("DELETE FROM funcoes WHERE idFuncao = ?", idFuncao) > 0;
    }
}
