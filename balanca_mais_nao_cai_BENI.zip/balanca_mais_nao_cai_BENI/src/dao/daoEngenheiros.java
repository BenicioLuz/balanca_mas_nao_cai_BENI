package dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import model.engenheiros;

public class daoEngenheiros extends JdbcDao {

    private engenheiros mapear(ResultSet resultado) throws SQLException {
        engenheiros engenheiro = new engenheiros();
        engenheiro.setIdEngenheiro(resultado.getInt("idEngenheiro"));
        engenheiro.setDsNome(resultado.getString("dsNome"));
        engenheiro.setNrCREA(resultado.getInt("nrCREA"));
        engenheiro.setDtAdmissao(resultado.getDate("dtAdmissao"));
        return engenheiro;
    }

    public boolean inserir(engenheiros engenheiro) throws SQLException {
        String sql = "INSERT INTO engenheiros (dsNome, nrCREA, dtAdmissao) VALUES (?, ?, ?)";
        return executar(sql, engenheiro.getDsNome(), engenheiro.getNrCREA(),
                engenheiro.getDtAdmissao()) > 0;
    }

    public boolean atualizar(engenheiros engenheiro) throws SQLException {
        String sql = "UPDATE engenheiros SET dsNome = ?, nrCREA = ?, dtAdmissao = ? "
                + "WHERE idEngenheiro = ?";
        return executar(sql, engenheiro.getDsNome(), engenheiro.getNrCREA(),
                engenheiro.getDtAdmissao(), engenheiro.getIdEngenheiro()) > 0;
    }

    public List<engenheiros> listar() throws SQLException {
        String sql = "SELECT idEngenheiro, dsNome, nrCREA, dtAdmissao "
                + "FROM engenheiros ORDER BY idEngenheiro";
        return consultar(sql, this::mapear);
    }

    public engenheiros buscarPorId(int idEngenheiro) throws SQLException {
        String sql = "SELECT idEngenheiro, dsNome, nrCREA, dtAdmissao "
                + "FROM engenheiros WHERE idEngenheiro = ?";
        List<engenheiros> resultados = consultar(sql, this::mapear, idEngenheiro);
        return resultados.isEmpty() ? null : resultados.get(0);
    }

    public boolean excluir(int idEngenheiro) throws SQLException {
        return executar("DELETE FROM engenheiros WHERE idEngenheiro = ?", idEngenheiro) > 0;
    }
}
