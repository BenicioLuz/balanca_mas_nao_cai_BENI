package dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import model.orcamentos_obras;

public class daoOrcamentosObras extends JdbcDao {

    private orcamentos_obras mapear(ResultSet resultado) throws SQLException {
        orcamentos_obras relacao = new orcamentos_obras();
        relacao.setIdOrcamento(resultado.getInt("idOrcamento"));
        relacao.setIdObra(resultado.getInt("idObra"));
        relacao.setDtInicio(resultado.getDate("dtInicio"));
        relacao.setDtFim(resultado.getDate("dtFim"));
        relacao.setVlPrevisto(resultado.getBigDecimal("vlPrevisto"));
        relacao.setVlRealizado(resultado.getBigDecimal("vlRealizado"));
        return relacao;
    }

    public boolean inserir(orcamentos_obras relacao) throws SQLException {
        String sql = "INSERT INTO orcamentos_obras "
                + "(idOrcamento, idObra, dtInicio, dtFim, vlPrevisto, vlRealizado) "
                + "VALUES (?, ?, ?, ?, ?, ?)";
        return executar(sql, relacao.getIdOrcamento(), relacao.getIdObra(),
                relacao.getDtInicio(), relacao.getDtFim(), relacao.getVlPrevisto(),
                relacao.getVlRealizado()) > 0;
    }

    public boolean atualizar(orcamentos_obras relacao) throws SQLException {
        String sql = "UPDATE orcamentos_obras SET dtInicio = ?, dtFim = ?, "
                + "vlPrevisto = ?, vlRealizado = ? "
                + "WHERE idOrcamento = ? AND idObra = ?";
        return executar(sql, relacao.getDtInicio(), relacao.getDtFim(),
                relacao.getVlPrevisto(), relacao.getVlRealizado(),
                relacao.getIdOrcamento(), relacao.getIdObra()) > 0;
    }

    public List<orcamentos_obras> listar() throws SQLException {
        String sql = "SELECT idOrcamento, idObra, dtInicio, dtFim, vlPrevisto, vlRealizado "
                + "FROM orcamentos_obras ORDER BY idOrcamento, idObra";
        return consultar(sql, this::mapear);
    }

    public List<orcamentos_obras> listarPorObra(int idObra) throws SQLException {
        String sql = "SELECT idOrcamento, idObra, dtInicio, dtFim, vlPrevisto, vlRealizado "
                + "FROM orcamentos_obras WHERE idObra = ? ORDER BY idOrcamento";
        return consultar(sql, this::mapear, idObra);
    }

    public orcamentos_obras buscar(int idOrcamento, int idObra) throws SQLException {
        String sql = "SELECT idOrcamento, idObra, dtInicio, dtFim, vlPrevisto, vlRealizado "
                + "FROM orcamentos_obras WHERE idOrcamento = ? AND idObra = ?";
        List<orcamentos_obras> resultados = consultar(sql, this::mapear, idOrcamento, idObra);
        return resultados.isEmpty() ? null : resultados.get(0);
    }

    public boolean excluir(int idOrcamento, int idObra) throws SQLException {
        String sql = "DELETE FROM orcamentos_obras WHERE idOrcamento = ? AND idObra = ?";
        return executar(sql, idOrcamento, idObra) > 0;
    }
}
