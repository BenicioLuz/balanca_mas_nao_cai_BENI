package dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import model.orcamentos;

public class daoOrcamentos extends JdbcDao {

    private orcamentos mapear(ResultSet resultado) throws SQLException {
        orcamentos orcamento = new orcamentos();
        orcamento.setIdOrcamento(resultado.getInt("idOrcamento"));
        orcamento.setDtOrcamento(resultado.getDate("dtOrcamento"));
        orcamento.setDtAprovacao(resultado.getDate("dtAprovacao"));
        return orcamento;
    }

    public boolean inserir(orcamentos orcamento) throws SQLException {
        String sql = "INSERT INTO orcamentos (dtOrcamento, dtAprovacao) VALUES (?, ?)";
        return executar(sql, orcamento.getDtOrcamento(), orcamento.getDtAprovacao()) > 0;
    }

    public boolean atualizar(orcamentos orcamento) throws SQLException {
        String sql = "UPDATE orcamentos SET dtOrcamento = ?, dtAprovacao = ? "
                + "WHERE idOrcamento = ?";
        return executar(sql, orcamento.getDtOrcamento(), orcamento.getDtAprovacao(),
                orcamento.getIdOrcamento()) > 0;
    }

    public List<orcamentos> listar() throws SQLException {
        String sql = "SELECT idOrcamento, dtOrcamento, dtAprovacao "
                + "FROM orcamentos ORDER BY idOrcamento";
        return consultar(sql, this::mapear);
    }

    public orcamentos buscarPorId(int idOrcamento) throws SQLException {
        String sql = "SELECT idOrcamento, dtOrcamento, dtAprovacao "
                + "FROM orcamentos WHERE idOrcamento = ?";
        List<orcamentos> resultados = consultar(sql, this::mapear, idOrcamento);
        return resultados.isEmpty() ? null : resultados.get(0);
    }

    public boolean excluir(int idOrcamento) throws SQLException {
        return executar("DELETE FROM orcamentos WHERE idOrcamento = ?", idOrcamento) > 0;
    }
}
